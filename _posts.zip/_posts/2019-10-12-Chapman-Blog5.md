---
layout: post
title: "Blog 5"
---

This week, my focus was Project 0. The goal was to host a site on an AWS instance. We split the tasks up and I have been focusing on generating TLS certificates for the DNS addresses. Goin into the task, I havent had prior experience creating certificates so the task was challenging. I spent nearly 8 hours in one day trying to make both DNS addresses secure. I had an issue of making one secure, but not the other. Certbot only allows a certain amount of certificates created within a 7 day period per domain, and we reached the limit before completing the task. At the moment, we are in the process of creating a new domain so we can move forward. The project is due on saturday and it's thursday now, so we don't have time for the limit to reset.
