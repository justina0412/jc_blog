---
layout: post
title: "Blog 3"
---

This is my second time writing blog 3. Everything was fine with github until i tried to push. It [rejected] and I got an error:

" ! [rejected]        gh-pages -> gh-pages (non-fast-forward)
error: failed to push some refs to 'https://github.com/justina0412/Blog_0.git'
hint: Updates were rejected because the tip of your current branch is behind
hint: its remote counterpart. Integrate the remote changes (e.g.
hint: 'git pull ...') before pushing again.
hint: See the 'Note about fast-forwards' in 'git push --help' for details."

It gives a hint to pull, but when I do I get this error message:

"From https://github.com/justina0412/Blog_0
 * branch            gh-pages   -> FETCH_HEAD
fatal: refusing to merge unrelated histories"

I tried a couple of git merge commands, but my blogs just got moved or deleted. This is the 4th week that I'm having an issue pushing my blogs. 
