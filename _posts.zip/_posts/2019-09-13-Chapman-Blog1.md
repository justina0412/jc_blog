---
layout: post
title: "Blog 1"
---

For the week of 9/7, I started a required lab which included installing a LAMP stack.


As stated before, I've created a small partition which I've allocated about 200GB for my Ubuntu OS. I'm in section 7 for lab 1 so far and haven't run into any issues. However, I ran the command "apt-get upgrade," I made the mistake of running it outside of my container, so it took over 20 minutes to complete. I didn't notice the mistake until the command was finished running so time was wasted. I'm currently in the process of completing the lab.


Since I was short on time, I was unable to figure out the issue with installing Docker on Windows properly. Hopefully, I will have time to resolve the issue this weekend. I will continue using Ubuntu because I find it easier with its command line.
