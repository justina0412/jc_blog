---
layout: post
title: "Blog 4"
---

The workload this week isn't as hectic due to the group project due next week. I was happy to find out that all of my issues with github were not going to cost me all of my blog post points. Apparently, I'm not the only one having issues with pushing posts onto github.com. Although I was shown how to push after the error was "resolved," I had an issue when attempting to push a post again! I'm officially starting from scratch. I've saved all of my completed blogs, deleted ALL of my repositories, and I'm starting over. If I have any issues going forward, I feel I'll be able to point them out better this time around. 

