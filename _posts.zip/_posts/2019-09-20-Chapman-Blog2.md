---
layout: post
title: "Blog 2"
---

This week and last week have been exceptionally challenging this semester.

Creating a dockerfile to create a LAMP stack for lab1 was challenging because I didn't know all of the proper  RUN commands to move forward. Luckily, a classmate was able to help guide me and to find a solution. In the end, it worked out.

Lab2 also has its challenges. So far I've been able to install ansible just fine, but I'm not sure exactly what to do to create a playbook using Docker. Since the date has been extended to 9/27, I intent on asking my classmates or the professor for some guidance so I can move forward. 

As a sidenote, I'm not sure why COMP 484 is a prerequisite to this course. So far the material between this class and 484 haven't aligned. Hopefully it will sometime soon. 

