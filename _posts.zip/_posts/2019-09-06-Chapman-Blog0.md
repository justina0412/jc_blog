---
layout: post
title: "Blog 0"
---

  So far in CIT, I haven't had any trouble using my Windows OS, until the first week of school during my last year of my undergrad!

  Although the assignment was given about 2 weeks ago, I didn't start until Labor day weekend. I figured completing the assignment a week in advance would be okay. It took nearly a week to figure out how to install Docker on Windows!

  While trying to install Docker, I ran into an endless amount of issues on Windows. First, it took a while to figure out how to install the version for Windows 10 Home Edition. Desktop only works with Windows 10 64-bit: Pro, Enterprise, or Education, and of course I don't have any of the listed. It took some research to learn that I needed to install the Docker Toolbox. With the toolbox, it creates VMs and installs a Docker command prompt to communicate with the VMs through Windows. I was able to install the VMs and command prompt okay, but there was an issue with running docker. I was constantly getting an error saying the daemon wasn't running. When that error was fixed, I was getting an error saying Docker had an issue "setting env..." I tried to uninstall and reinstall, except uninstalling isn't as simple as removing the app. I still need help uninstalling properly.

  I finally gave up on Windows. I then created a bootable drive with Ubuntu and created a partition (I have 2TB) and have been working on Ubuntu with Docker effortlessly.

  The moral of the story is, don't use Windows 10 Home Edition for Docker!
