---
layout: post
title: "Blog 6"
---

Last week, the due date of Project 0 got extended for 1 week due to the fires. Did we finish the project way before the xtension date? Nope. I actually had to wait exactly 7 days to try and create a certificate for the site because the limit was reached last week. I was able to secure www.domain.net, but haven't tried cit480.net. When asking the professor for advide regarding securing the site, she stated securing www.domain.net is acceptable, but I'm still going to try and secure domain.net before class saturday. Luckily, a buddy of mine in the class was successful and gave me a few tip that I can try. Hopefully I will be able to complete the task successfully. 
